CREATE TABLE `player_aura_mods` (
  `guid` bigint(20) NOT NULL,
  `aura_id` int(11) NOT NULL,
  `mod1_type` int(11) NOT NULL,
  `mod1_amount` int(11) NOT NULL,
  `mod1_miscValue` int(11) NOT NULL,
  `mod2_type` int(11) NOT NULL,
  `mod2_amount` int(11) NOT NULL,
  `mod2_miscValue` int(11) NOT NULL,
  `mod3_type` int(11) NOT NULL,
  `mod3_amount` int(11) NOT NULL,
  `mod3_miscValue` int(11) NOT NULL,
  KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;