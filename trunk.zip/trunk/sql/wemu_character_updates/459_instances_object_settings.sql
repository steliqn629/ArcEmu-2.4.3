CREATE TABLE `instances_object_settings` (
  `id` int(11) NOT NULL auto_increment,
  `instance_id` int(11) NOT NULL,
  `go_sql_id` int(11) NOT NULL,
  `update_field_index` int(11) NOT NULL,
  `update_field_int_value` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `index_id` (`instance_id`,`go_sql_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;