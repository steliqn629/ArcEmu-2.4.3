/* 
Event  : Winter Veil Despawn
Author: Angelis
Team   : Sun++
*/

/* DELETE QUERY */
/*=============== GAMEOBJECT ===============*/
DELETE FROM `gameobject_names` WHERE entry = '180797';
DELETE FROM `gameobject_spawns` WHERE entry = '178425';
DELETE FROM `gameobject_spawns` WHERE entry = '178426';
DELETE FROM `gameobject_spawns` WHERE entry = '178428';
DELETE FROM `gameobject_spawns` WHERE entry = '178429';
DELETE FROM `gameobject_spawns` WHERE entry = '178430';
DELETE FROM `gameobject_spawns` WHERE entry = '178431';
DELETE FROM `gameobject_spawns` WHERE entry = '178432';
DELETE FROM `gameobject_spawns` WHERE entry = '178433';
DELETE FROM `gameobject_spawns` WHERE entry = '178434';
DELETE FROM `gameobject_spawns` WHERE entry = '178437';
DELETE FROM `gameobject_spawns` WHERE entry = '178554';
DELETE FROM `gameobject_spawns` WHERE entry = '178556';
DELETE FROM `gameobject_spawns` WHERE entry = '178557';
DELETE FROM `gameobject_spawns` WHERE entry = '178609';
DELETE FROM `gameobject_spawns` WHERE entry = '178645';
DELETE FROM `gameobject_spawns` WHERE entry = '178647';
DELETE FROM `gameobject_spawns` WHERE entry = '178649';
DELETE FROM `gameobject_spawns` WHERE entry = '180796';
DELETE FROM `gameobject_spawns` WHERE entry = '187236';

/*=============== CREATURE ===============*/
DELETE FROM `creature_spawns` WHERE entry = '15760';
DELETE FROM `creature_spawns` WHERE entry = '13444';
DELETE FROM `creature_spawns` WHERE entry = '13445';