#ifndef ADT_H
#define ADT_H

#define TILESIZE (533.33333f)
#define CHUNKSIZE ((TILESIZE) / 16.0f)
#define UNITSIZE (CHUNKSIZE / 8.0f)

#include <array>
using namespace std::tr1;

template<class T, const size_t array_size, const int default_value = 0> class MyArray : public std::tr1::array<T, array_size>
{
#define ARRAY_TEMP MyArray<T, array_size, default_value>
public:
	MyArray()
	{
		ARRAY_TEMP::_Init(default_value);
	}

	MyArray(T default_val)
	{
		ARRAY_TEMP::_Init(default_val);
	}

	~MyArray()	{}

	bool Contains(T value)
	{
		ARRAY_TEMP::const_iterator itr = ARRAY_TEMP::begin();
		for(;itr != ARRAY_TEMP::end();++itr)
		{
			if((*itr) == value)
				return true;
		}
		return false;
	}

private:
	void _Init(T default_val)
	{
		ARRAY_TEMP::assign(static_cast<T>(default_val));
	}
#undef ARRAY_TEMP
};

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

class Liquid;
class WMO;
class WMOManager;
class MPQFile;

struct svec
{
	svec()
	{
		x = y = z = 0.0f;
	}

	float x;
	float y;
	float z;
};

struct vec
{
	vec()
	{
		x = y = z = 0;
	}

	double x;
	double y;
	double z;
};

struct triangle
{
	array<vec, 3> v;
};	

struct Cell
{
	MyArray<MyArray<float, 16*8+1>, 16*8+1> v9;
	MyArray<MyArray<float, 16*8>, 16*8>		v8;
};

struct MapCellInfo
{
	MyArray<MyArray<uint16, 2>, 2>	AreaID;
	MyArray<MyArray<uint8, 2>, 2>	LiquidType;
	MyArray<MyArray<float, 2>, 2>	LiquidLevel;
	MyArray<MyArray<float, 32>, 32>	Z;
}; 


struct zstore
{
	MyArray<MyArray<float, 256>, 256>	z;
};

struct chunk
{
	chunk()
	{
		area_id		= 0;
		waterlevel	= 0.0f;
		flag		= 0;
	}

	MyArray<MyArray<double, 9>, 9> v9;
	MyArray<MyArray<double, 8>, 8> v8;
	uint16 area_id;
	float waterlevel;
	uint8 flag;
};

struct mcell
{
	array<array<chunk, 16>, 16> ch;
};

void fixname(std::string &name);
void LoadMapChunk(MPQFile &, chunk*);
void LoadH2OChunk(MPQFile &, chunk*, uint32);
bool LoadWMO(char* filename);

#endif

