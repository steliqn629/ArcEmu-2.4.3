inside your wow directory create forlders

	maps
	mmaps
	vmaps

to folder vmaps copy from emulator folder or make new vmaps
then run adgrid.exe inside your wow directory, this takes 2 minutes max
then run MoveMapGenerator.exe inside your wow directory (this takes like 3-4 days 1 CPU and -+300MB Ram)
after this copy folder mmaps to your emulator folder, compile rev 845 or higher and enjoy pathfinding :)