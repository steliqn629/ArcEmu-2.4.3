<?php
$dbhost="localhost";
$dbuname="root";
$dbupass="";
$dbname="spellsonly";
?>