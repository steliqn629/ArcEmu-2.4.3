This is an open source library of random number generators by Agner Fog
published at www.agner.org/random/.
See ran-instructions.pdf for instructions and documentation.